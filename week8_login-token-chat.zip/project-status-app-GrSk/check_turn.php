<?php
session_start();
require 'db.php';

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "Not logged in"]);
    exit;
}

$user_id = $_SESSION["user_id"];

$turn_check = $conn->query("SELECT current_user FROM turns LIMIT 1");
$turn_data = $turn_check->fetch_assoc();

if ($turn_data["current_user"] == $user_id) {
    echo json_encode(["isMyTurn" => true]);
} else {
    echo json_encode(["isMyTurn" => false]);
}
?>
