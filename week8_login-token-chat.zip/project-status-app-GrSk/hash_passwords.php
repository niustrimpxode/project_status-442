<?php
$password = 'admin123';  
$hashedPassword = '$2y$10$9MWQALb3cKWbRBDv0BoEMuCUEFHpOdG3.tKLd2bRAW1SxxVRhS.n.'; 

if (password_verify($password, $hashedPassword)) {
    echo "Password is correct";
} else {
    echo "Password is incorrect";
}
// check if hashing works
// check if hashing works
// check if hashing works
// check if hashing works
// check if hashing works
?>
