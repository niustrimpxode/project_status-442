<?php
include 'db.php';

$result = $conn->query("SELECT username, message, timestamp FROM chat ORDER BY timestamp DESC LIMIT 20");

$messages = "";
while ($row = $result->fetch_assoc()) {
    $messages .= "<p><strong>{$row['username']}:</strong> {$row['message']} <small>({$row['timestamp']})</small></p>";
}
echo $messages;
?>
