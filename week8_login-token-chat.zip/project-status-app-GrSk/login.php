<?php
session_start();
include 'db.php';  
require_once 'jwt/src/JWT.php';  

use \Firebase\JWT\JWT;  

$secretKey = 'JWTSECRET';  

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);  
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        if (password_verify($password, $hashedPassword)) {
            $_SESSION["username"] = $username;  

            $payload = array(
                "username" => $username,
                "iat" => time(), 
                "exp" => time() + 3600 
            );

            $jwt = JWT::encode($payload, $secretKey, 'HS256');

            $updateStmt = $conn->prepare("UPDATE users SET token = ? WHERE username = ?");
            $updateStmt->bind_param("ss", $jwt, $username);
            if ($updateStmt->execute()) {
                echo json_encode(array("success" => true, "jwt" => $jwt));  
            } else {
                echo json_encode(array("error" => "Failed to update token in database"));
            }
            $updateStmt->close();
        } else {
            echo json_encode(array("error" => "Incorrect password"));
        }
    } else {
        echo json_encode(array("error" => "User not found"));
    }
    $stmt->close();
}
?>
