<?php
session_start();
include 'db.php';

if (!isset($_SESSION["username"])) {
    die("Not logged in");
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["message"])) {
    $message = trim($_POST["message"]);
    $username = $_SESSION["username"];

    if (!empty($message)) {
        $stmt = $conn->prepare("INSERT INTO chat (username, message) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $message);
        $stmt->execute();
        $stmt->close();
    }
}
?>
